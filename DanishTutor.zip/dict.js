dict={
    chapter1:{
        page0:{
            //https://www.youtube.com/watch?v=T0MwtvJjHfM&t=2s&ab_channel=B%C3%B8rneTV
            //Gurli Gris 1 - 32 Tordenvejret
             'Jeg hedder':'I am',   
            '':'',
           
        },
        page1:{
            'grim':'ugly',
            'skynd dig':'hurry up',
            'fridag':'day off',
            'julepynt':'Christmas decorations',
            "rette ud":"straighten out",
		  	'Det er bare dejligt':"It's just nice",
            'krydderier':'spices',
            "et sprog":'language',
            "sådan her":"like this",
            "snart":"soon",
        },
        page2:{
            //https://youtu.be/nhb89cifxW8?t=16
            //Gurli Gris | Skattejagten
            
            'det var flot':'it was great',
            'dernede':'down there',
            'skatten':'treasure',
            "kiste":"chest",
            "utroligt":"incredible",
            "skattejagt":"treasure hunt",
            "udenfor":"outside",
            "indenfor":"inside",
            "meget koldt":"very cold",


        },
        page3:{
            //https://youtu.be/a58Phhm8kuI
            //Gurli Gris 1 - 33 Bilvask
            'faret vild':'got lost',
            'snavset':'dirty',
            'ikke såslemt':'not so bad',
            'rod':'mess',
            'rodehoved':'messy person',
            'skrald':'garbage',
            'de er mine':'those are mine',
            'ryd op!':'tidy up!',
            'hente nogle':'get some',
            'svampen':'sponge',
            //----------------------------------//
            'er du klar':'are you ready',
            'vaske':'wash',
            'han er for lille':'he is too small',
            'stakkels dreng':'poor boy',
            'undskyld':'sorry',
           
        
        },
        page4:{
            'har smidt':'have thrown',
            'haveslange':'garden hose',
            'tænde for':'turn on',
            'slukke for':'turn off',
            'lys':'light',
            'sluk for lyset': 'turn off the light',
            'tænd for lyset': 'turn on the light',
            'hold op':'stop',
            'alle sammen':'everyone',
            'er våde':'are wet',
            "han er våd":"he is wet",
            'tør':'dry',
            'ren':'clean',
            'slemme':'bad',
        },

        page5:{
           //snow
            'huske':'remember',
            'halstørklæde':'scarf',
            'hue':'hat',
            'huer':'hats',
            'jeg vandt':'I won',
            'snyd': 'cheating',
            'yndlings': 'favorite',
            'det jeg også':'so am I',
            'virker':'works',
            'begge fødder':'both feet',
            "plaske":"splash",
            'hold fast':'hold on',
            'hold nu fast':'wow',
            'øve':'practice',

        }, 
         page6:{
            //gurli gris s02e20 - dansk tale  svomning
            //https://youtu.be/zgKECHrWpU4
            "spark":"kick",
            'spark med benene':'kick with legs',
            'lade være med':'stop it',
            'store børn':'big kids',
            "rigtig godt":"really good",
            'tabt':'lost',
            'ned':'down',
            'op':'up',
            "lige":"straight",
            'venstre':'left',
            'højre':'right',
            'desværre':'unfortunately',
            'på samme tid':'at the same time',

        }, 
         page7:{
             //https://youtu.be/Gsggd7RT7O0
             //Gurli Gris | Cykler 
            "kedelig":"boring",
            'vigtig':'important',
            'aflevere':'deliver',
            'gave':'present',
            "løbet":"the race",
            'nej det gjorde du ikke':"no you didn't",
            'du kan ikke':"you can't",
            'fange mig':'catch me',
            "op ad bakke":"uphill",
            'stejl bakke':'steep hill',
            'smukke':'beautiful',
            'hårdt arbejde':'hard work',
            'ned ad bakken':'downhill',
            'træt':'tired',


        }, 
         page8:{
            "bakke":"hill",
            'meget høj':'very high',
            'meget høj bakke':'very high hill',
            'kedelig':'boring',
            "skøn":"wonderful",
            'udsigt':'view',
            'skøn udsigt':'wonderful view',
            'kort':'map',
            'er du sikker':'are you sure',
            "kjole":"dress",
            'min tur':'my turn',
            'himlen':'the sky',
            'ved du':'do you know',
            'hvor vi er':'where we are',
            'hele dagen':'all day',
            'fare lidt vild':'get a little lost',
            'knotten':'irritated',
            'se':'look',
            'indenfor':'inside',
            '':'',   
            '':'',

        },
        page9:{
            //https://youtu.be/iolFBh6OrTA?t=17
            //Gurli Gris 2 - 22 På Arbejde Med Far Gris
            
            'søvnig':'sleepy',   
            'øverste knap':'top button',
            'øverste etage':'top floor',   
            'store tal':'big numbers',
            'alvorlig':'serious',   
            'vigtig':'important',
            'tegne':'draw',
            'løber tør':'run out',
            'reddede os':'saved us',   
            'spændende':'exciting',
            'luft':'air',    
            'dækket':'the tire',
            'fremtiden':'the future',   
            'gør noget':'do something',
             'måske':'maybe',   
            'skulle jeg ':'I should',
             'prøve':'try',   
            'reparere computer':'fix computer'



        }

    },
    chapter2:{
        page0:{
            //https://www.youtube.com/watch?v=T0MwtvJjHfM&t=2s&ab_channel=B%C3%B8rneTV
            //Gurli Gris 1 - 32 Tordenvejret
             'Jeg hedder':'I am',   
            '':'',
           
        },
        page1:{
            //https://www.youtube.com/watch?v=T0MwtvJjHfM&t=2s&ab_channel=B%C3%B8rneTV
            //Gurli Gris 1 - 32 Tordenvejret
             'småkager':'cookies',   
            'lyd':'sound',
            'mærkelig lyd':'strange sound',   
            'inde i huset':'inside the house',
            'torden':'thunder',   
            'langt væk':'far away',
            'mørkere':'darker',   
            'det bliver':'it will be',
            'glemt':'forgotten',   
            'i haven':'in the garden',
            'snart':'soon',   
            'Hvad sagde jeg':'what did i say', 
        },
        page2:{
            'det sker':'it happens',
            'med':'with',
            'en smule':'a bit',
            'stakkels dreng':'poor boy',   
            'stakkels lille ting':'poor little thing',
            'lå i sengen':'lay in bed',  
            'modig':'brave',
            'store og modige':'big and brave',   
            'selvfølgelig':'ofcourse',
            'umulig':'impossible',
            'det er stille':'it is quiet',
            'det er så stille':'it is so quiet',   
            'han er bedre':'he is better',   
           


        },
        page3:{
        	//Gurli Gris 4 - 35 Natdyr
            'sengetid':'bedtime',
            'bare rolig':"don't worry",
            'samle':'collect',
            'grøntsager':'vegetables',
            'lommelygte':'flashlight',
            'Vær venlig':'please',
            'i spanden':'in the bucket',
            'pind':'stick',
            'pindsvin':'hedgehog',
            'Vær bange':'be scared',
            'sommerfugle':'butterflies',
            'ildflue':'firefly',
            //------------------------//
            
           

        },
        page4:{
            	//Gurli Gris 4 - 35 Natdyr
            'op i himlen':'',
            'op i himlen':'up in the sky',
            'stjerneskud':'shooting star',
            'ildsted':'fireplace',
            'mave':'tummy',
            'sengetid':'bedtime',
            'jakke og støvler':'jacket and boots',
            'for lang tid':'too long time',
            'snegl':'snail',
            'høns':'hens',
            'tænde ':'turn on',
            'sluk':'turn off',
            'prøve':'try',
            'natdyr':'night animals',
            


        },
        page5:{
            //Gurli Gris 1 - 22 Tandfeen
            //https://youtu.be/HtkHSWG9Ti0
            'tand':'tooth',
            'yndlingsret':'favorite dish',
            'larme':'make noise',
            'Hvad er det':'What is it',
            'skulle du se':'you should see',
            'spejl':'mirror',
            'det er min':'it is my',
            'det faldt ud':'it fell out',
            'mælketand':'milk tooth',
            'det skal fell ud':'it should fall out',
            'mynt':'coin',
            'børste tænder':'brush teeth',
            'under puden':'under pillow',

        },
         page6:{
             //bedtime gurli gris
            //https://youtu.be/Z4d36lmtRII
            'badetid':'bath time',
            'skynd dig':'hurry up',
            'lidt mere':'a little more',
            'men':'but',
            'plaske':'splash',
            'ikke mere':'no more',
            'lidt længere':'a little longer',
            'er forbi':'is over',
            'nu skal du':'now you should',
            'børste tænder':'brush teeth',
            'er forbi':'is over',
            'altid':'always',
            'i seng':'in bed',
            'læse bog':'read a book',
            
           

        },
        page7:{
            //bedtime gurli gris
            //https://youtu.be/Z4d36lmtRII

            'Jeg er lidt':'I am a little',
            'træt':'tired',
            'sengetid':'bedtime',
            'søvnig':'sleepy',
            'må vi lege':'can we play ',
            'udenfor':'outside',
            'hoppe':'jump',
            'i mudderet':'in the mud',
            'han elsker':'he loves',
            'største':'largest',
            //----------------------------------//
            'verdens største':'worlds biggest',
            'Det kan jeg see':'I can see that',
            'hurtig':'fast',

        },
        
        page8:{
            //https://youtu.be/SM_s5cwE4z0    dat
            //https://youtu.be/yPsywDWFjOg    eng
            'købe':'buy',
            'elsker at sidde':'loves sitting',
            'Må jeg':'can I',
            'indkøbsvogn':'shopping cart',
            'på listen':'on the list',
            'Denne vej':'this way',
            'læg dem':'put them',
            'også':'also',
            
            'vognen':'cart',
            'godt gået':'well done',



        },page9:{
            //https://youtu.be/SM_s5cwE4z0    dat
            //https://youtu.be/yPsywDWFjOg    eng
           
            'det var flot'  :' great',
            'jeg kan se den':'I can see it',
            'kan ikke huske':'cannot remember',
            'løg'           :'onions',
            'sidste ting'   :'last thing',
            ' Seddel'       :'note',
            
            ' det hedder'   :'it is called',
            ' strege dem'   :'cross it out',
            
            'er det på listen':'is it on the list',
            'du kan vælge'  :'you can choose',
            'hvem sagde det':'who put it',
            'slemme dreng'  :'bad boy',
            'lækker'        :'delicious',
            'lade som om'   :'pretend',


        },
    },
    chapter3:{
        page0:{
            //https://www.youtube.com/watch?v=nS7tEY5gSJA&ab_channel=B%C3%B8rneTV
            //Gurli Gris 1 - Sna 

            'sne'           :' snow',
            'glad'           :'happy',
            'meget kold'    :'very cold',
            ' huske'        :'remember',
            'hue'           :'hat',
            'halstørklæde'   :'scarf',

            ' vanter'        :'gloves',
            ' fodspor'      :'footprints',
            ' rigtig sjovt' :'really fun',
            
            'kroppen'       :'the body',
            'hoved'         :'head',
            'ansigt'        :'face',
            'mund'          :'mouth',
            'tøj'           :'clothing',
           
           
        },
        page1:{
            //Peppa Pig - Lunch (full episode)
            //https://youtu.be/Ez0qR3m1G4g
            //Gurli Gris 1 - 34 Frokost
            //https://youtu.be/dvavLd3Xq5Y
            'frokost':'lunch',
            'have':'garden',
            'lad os finde':"let's find",
            'hente nogle':'pick up some',
            'kan du li':'do you like',
            'agurk':'cucumber',
            'skør':'crazy',
            'dejlig':'lovely',
            'skyl grøntsagerne':'rinse the vegetables',
            
        },
        page2:{
            //Peppa Pig - Lunch (full episode)
            //https://youtu.be/Ez0qR3m1G4g
            //Gurli Gris 1 - 34 Frokost
            //https://youtu.be/dvavLd3Xq5Y
            'nok':'enough',
            'lave':'make',
            'lav salat':'make salad',
            'prøve':'try',
            'lækker':'delicious',
            'spise':'eat',
            'jeg er mæt':'i am full',
            'det er trist':"that's sad",
            'slet ikke':'not at all',

        },
        page3:{
           // Gurli Gris 1 - 39 Museet
           // https://youtu.be/W72JGtCPHTw    //dk
           //https://youtu.be/1ckFNhI9F5Y     //en
  
           'hvad er':'what is',
           'det er sted':'it is place',
           
           'være roligt':'be calm',
           'meget gammel':'very old',
           'konge':'king',
           'konger og dronninger':'kings and queens',
           'voksne':'adults',
           'stol':'chair',
           'mere kage':'more cake',
           'kongelig højhed':'royal highness',
           'meget stor':'very big',
           'knogle':'bone',
           'forestiller ':'imagines',
           'yndling ':'favorite',


        },
        page4:{
            //https://youtu.be/QgUjWDX6RgU
            'nemt  ':'easily',
            'tilvaerelsen  ':'existence',
            'bolig  ':'housing',
            'selv om sommeren':'even in the summer',
            'overdrive   ':'exaggerate',

            'unge  ':'young',
            'muligheder  ':'options',
            'billigt  ':'cheap',
            'ungdommen  ':'the youth',
            'skrive':'write',
            
            'hvis  ':'whose',
            'dovne':'lazy',
            'fremstilling':'manufacturing',
            'offentlige':'public ',
            'tjenester':'services',
            'landbrug ':'agriculture',
            


        },
        page5:{
            //Recycling
            //https://youtu.be/Z2AD0FltGBw  dat 
            //https://youtu.be/LIP-EN7Ygro  eng
            'genbrug':'recycling',
            'skralde':'garbage',
            'skraldemand':'garbage man',
            'tyr':'bull',
            'stille':'quiet',
            
            'har tømt':'has emptied',
            'flaske':'bottle',
            'hvad betyder det':'what does it mean',
            'skraldespand':'garbage bin',
            'dåser':'tin cans',

            'kasse':'box',
            'avis':'newspaper',
            'klar':'ready',
            
            

        },
         page6:{
            
            'hvad er':'',

            '':'',
            '':'',
            '':'',
            '':'',
            '':'',

            '':'',
            '':'',
            '':'',
            '':'',
            '':'',
            '':'',
            '':'',
            '':'',

        },
    }
}

        /*
        var Danish  =["folk"   ,"skal"    ,"flere" , "tiden"     ,"rejse",      "døde",      "om",   "kigge", "sidste","uge"  , "hvorfor","hvordan","tilføje","ting","nemlig","forsamlinger forbudt "];
        var English =["people","should","more"     ,"the time"   ,"travel"     ,"dead",       "about","look",  "last",  "week","why"    ,    "how", "add"   , "thing","exactly","gatherings forbidden"];
        var Danish2 =["det sker"  ,"med","en smule","steget"   ,"penge","dyrere"        ,"bolig"   ,"kræver" ,"beslutning","åbne","han betaler","priserne"," falder"    ,"fortsæt"  ,"muligt"  ,"jeg mener","virkelig","første gang","spise","øjeblik","mange","meget","noget mad"];
        var English2=["it happens","with","a bit"  ,"increased","money","more expensive","property","demands","decision"  ,"open","he pays"   ,"the prices","are falling","continue","possible","I think"  ,"really"  ,"first time" ,"eat"  ,"moment"  ,"many","a lot","some food"];
        var Danish3 =["betyder","genert","larmende","sød" ,"hoppe i mudder","vindue","hurtigere","kender","sikkert", "efter","falde i søvn","egentlig","hjernen","vejr"     ,"vejret","vigtigt"];
        var English3=["means"  ,"shy"   ,"noisy"    ,"sweet","jump in mud","window","faster","know"     ,"certainly","after","fall asleep" ,"actually","the brain","weather","the weather","important"];
        
        var Danish4 =["afskyeligt" ,"rask"   ,"Jeg ringer","prikker","ansigt","pilene","slet ikke","det blæser"  ,"vær forsigtig"   ,"tung","reddet","solskinsdag"   ,"regndag" ,"rutsjebane"    ,"stadig"  ,"flyve","vind","vente"];
        var English4 =["disgusting","healthy","I am calling","dots"    ,"face"  ,"arrows","not at all","it blows","be careful"    ,"heavy","saved","sunny day"  ,"rainy day","rollercoaster","still","fly"   ,"wind","wait"];
        
        var Danish5 =["forsamlinger","selskabet ","ville ikke","frivilligt","halve antal"  ,"antal passagerne"  ,"anbefalingerne","to meters","afstand","undgå ","tæt  ","kontakt  ","at forhindre"," smitte"];
        var English5 =["gatherings","the company","would not","voluntary","half the number","number of passengers","recommendations","two meters","away","avoid","close","contact","to prevent","infection"];
        
        var Danish6 =["prøv igen","sjovt","endelig","beskytter","vente","udtaler"     ,""];
        var English6 =["try again","fun","finally","protects"  ,"wait","pronunciation",""];

        var Danish7 =["hvem er det","klar","hemmelig","hemmelig ting","dejlig","dårlig","nok","hvor gammel","Jeg hvisker","Jeg keder mig","valg","stue"         ,"tillyke","Tillyke med fødselsdagen"];
        var English7 =["who is it" ,"ready","secret","secret stuff","nice","bad","enough"    ,"how old"    ,"I whisper","I am bored"   ,"choise","living room"  ,"congratulations","Happy birthday"];
        
        var Danish8 =["hide der","gensidig","spændende","ballade","side om side","afholde fest","fint nok","frisk"  ,"fisk","vildsvin"];
        var English8 =["right there","mutual","exciting","trouble","side by side","hold a party","good enough","fresh","fish","wild pig"];

        var Danish9 =["hvem er det?","hvor er du?","hvad","hvorfor","hvordan","hvilken","hvornår","hvor meget?","hvor mange?"];
        var English9 =["who is it?","where are you?","what","why","how"     ,"which","when"     ,"how much?"    ,"how many?"];
*/